from csv import reader
from datetime import datetime
from domain.aggregated_data import AggregatedData

from domain.gps import Gps
from domain.accelerometer import Accelerometer

class DataSource:
    def __init__(self,files:list)->None:
        # Initialize data dictionary to store file data
        self.data = {}
        # Iterate through the list of files
        for file_data in files:
                # Extract the name of the file from the path
                name = file_data['name'].split('/')[-1].split('.')[0]
                # Initialize data structure for each file
                self.data[name] = {"iter":0,"data":[]}
                # Open the file and read its contents
                with open(file_data["name"],'r') as csv_f:
                    rdr = reader(csv_f,delimiter=",")
                    # Parse each row of the CSV file based on the provided structure
                    for row in rdr:
                        res = self.__parse_line(row,file_data["struct"])
                        if res is not None:
                            self.data[name]["data"].append(res)
        return None



    @staticmethod
    def __parse_line(line:list,line_struct:list)->list:
        try:
            # Parse each element in the line based on the structure
            return [line_struct[ind](line[ind]) for ind, unit in enumerate(line)]
        except Exception:
            return None
        
    def read(self)->AggregatedData:
        # Read data from different sources and create an AggregatedData object
        res = AggregatedData(
            accel=Accelerometer(
                x=self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][0],
                y=self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][1],
                z=self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][2]),
            gps=Gps(
                longtitude=self.data["gps"]["data"][self.data["gps"]["iter"]][0],
                latitude=self.data["gps"]["data"][self.data["gps"]["iter"]][1]),
            time=datetime.now())
        # Update the iteration index for each data source
        for k in self.data.keys():
            self.data[k]["iter"] += 1
            # Reset iteration index if it reaches the end of data
            if self.data[k]["iter"] == len(self.data[k]["data"]):
                self.data[k]["iter"] = 0
        return res

    def startReading(self,*args,**kwargs):
        # Placeholder method for starting recording
        pass


    def stopReading(self,*args,**kwargs):
        # Method to stop recording and clear data based on method type
        for i,_ in enumerate(self.data):
            match self.method:
                # Assuming self.method is defined somewhere else
                case 0:
                    # Clear data and reset iteration index for all sources
                    for i,_ in enumerate(self.data):
                        self.data[i]["data"].clear()
                        self.data[i]["iter"] = 0
                case 1:
                    # Clear structure and close pointer for all sources
                    for i,_ in enumerate(self.data):
                        self.data[i]["struct"].clear()
                        self.data[i]["ptr"].close()
                    

if __name__ == "__main__":
    # Initialize DataSource object with file names and corresponding structures
    src = DataSource([
        {"name":"./src/data/accelerometer.csv","struct":[int,int,int]},
        {"name":"./src/data/gps.csv","struct":[float,float]}])
