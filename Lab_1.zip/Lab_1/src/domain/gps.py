from dataclasses import dataclass

@dataclass
class Gps:
    long: float
    lat: float