from marshmallow import Schema,fields
from domain.gps import Gps

class GpsSchema(Schema):
    longtitude=fields.Number()
    latitude=fields.Number()