from app.entities.agent_data import AgentData
from app.entities.processed_agent_data import ProcessedAgentData

def scale_road_state(data:float):
    # Scales road state depending on z axis
    if(data <= 3000):       return "Excellent"
    elif(data <= 7000):     return "Good"
    elif(data <= 10000):    return "Fair"
    elif(data <= 13000):    return "Poor"
    elif(data <= 16000):    return "Bad"
    elif(data <= 20000):    return "Awful"
    else:                   return "Unscalable"
    return ""

def process_agent_data(agent_data: AgentData) -> ProcessedAgentData:
    """
    Process agent data and classify the state of the road surface.
    Parameters:
        agent_data (AgentData): Agent data that containing accelerometer, GPS, and timestamp.
    Returns:
        processed_data_batch (ProcessedAgentData): Processed data containing the classified state of the road surface and agent data.
    """
    res = ProcessedAgentData(road_state = scale_road_state(agent_data.accelerometer.z),
                             agent_data = agent_data)
    return res
