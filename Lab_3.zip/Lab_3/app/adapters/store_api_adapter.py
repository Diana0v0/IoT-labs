import json
import logging
from typing import List

import pydantic_core
import requests # type: ignore

from app.entities.processed_agent_data import ProcessedAgentData
from app.interfaces.store_api_gateway import StoreGateway
import datetime

def convert_data_to_dictionary(data: ProcessedAgentData) -> dict:
    """
    Convert ProcessedAgentData object to a dictionary with ISO-formatted datetime strings.
    Args:
        data (ProcessedAgentData): The data to convert.
    Returns:
        dict: The converted dictionary.
    """
    # Get the dictionary representation of the data object
    converted_data = data.model_dump()
    # Iterate through each key-value pair in the dictionary
    for key, value in converted_data.items():
        # If the value is a datetime object, convert it to ISO format
        if isinstance(value, datetime.datetime):
            converted_data[key] = value.isoformat()
        else:
            # If the value is a nested dictionary, iterate through its items
            if isinstance(value, dict):
                # If a nested value is a datetime object, convert it to ISO format
                for sub_key, sub_value in value.items():
                    if isinstance(sub_value, datetime.datetime):
                        value[sub_key] = sub_value.isoformat()
    # Return the converted dictionary
    return converted_data


class StoreApiAdapter(StoreGateway):
    def __init__(self, api_base_url):
        self.api_base_url = api_base_url

    """
    Save a batch of ProcessedAgentData objects to the Store API.
    Args:
        processed_agent_data_batch (List[ProcessedAgentData]): The batch of data to save.
    Returns:
        bool: True if data was successfully saved, False otherwise.
    """
    def save_data(self, processed_agent_data_batch: List[ProcessedAgentData]) -> bool:
        # Convert each ProcessedAgentData object in the batch to a dictionary
        data_to_save = [convert_data_to_dictionary(data) for data in processed_agent_data_batch]
        try:
            # Send a POST request to the API endpoint with the data to save
            response = requests.post(f"{self.api_base_url}/processed_agent_data/", json = data_to_save)
            # Check if the request was successful (status code 200)
            if response.status_code == 200:
                logging.info("Data successfully saved.")
                return True
            else:
                # Log an error message if the request failed
                logging.error(f"Failed to save data. Response status: {response.status_code},
                                Response body: {response.text}")
                return False
        except requests.exceptions.RequestException as exception:
             # Log an error message if an exception occurred during the request
            logging.error(f"Error: Something went wrong while trying to save data: {exception}")
            return False
