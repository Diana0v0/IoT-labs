from csv import reader
from datetime import datetime

from app.entities.agent_data import GpsData
from app.entities.agent_data import AccelerometerData
from app.entities.agent_data import AgentData
from app.entities.processed_agent_data import ProcessedAgentData

from threading import Thread
import time
import json

class DataSource:
    def __init__(self, files:list)->None:
        # Initialize data dictionary to store file data
        self.data = {}
        # Iterate through the list of files
        for file_data in files:
                # Extract the name of the file from the path
                name = file_data['name'].split('/')[-1].split('.')[0]
                # Initialize data structure for each file
                self.data[name] = {"iter": 0, "data": []}
                # Open the file and read its contents
                with open(file_data["name"],'r') as csv_f:
                    rdr = reader(csv_f, delimiter = ",")
                    # Parse each row of the CSV file based on the provided structure
                    for row in rdr:
                        res = self.__parse_line(row, file_data["struct"])
                        if res is not None:
                            self.data[name]["data"].append(res)
        return None



    @staticmethod
    def __parse_line(line:list, line_struct:list)->list:
        try:
            # Parse each element in the line based on the structure
            return [line_struct[ind](line[ind]) for ind, unit in enumerate(line)]
        except Exception:
            return None
        
    def read(self)->AgentData:
        # Read data from different sources and create an AggregatedData object
        res = AgentData(
            accel = AccelerometerData(
                x = self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][0],
                y = self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][1],
                z = self.data["accelerometer"]["data"][self.data["accelerometer"]["iter"]][2]),
            gps = GpsData(
                longtitude = self.data["gps"]["data"][self.data["gps"]["iter"]][0],
                latitude = self.data["gps"]["data"][self.data["gps"]["iter"]][1]),
            time = datetime.now())
        # Update the iteration index for each data source
        for key in self.data.keys():
            self.data[key]["iter"] += 1
            # Reset iteration index if it reaches the end of data
            if self.data[key]["iter"] == len(self.data[key]["data"]):
                self.data[key]["iter"] = 0
        return res

    def startReading(self, *args, **kwargs):
        # Placeholder method for starting recording
        pass


    def stopReading(self, *args, **kwargs):
        # Method to stop recording and clear data based on method type
        for i,_ in enumerate(self.data):
            match self.method:
                case 0:
                    # Clear data and reset iteration index for all sources
                    for i,_ in enumerate(self.data):
                        self.data[i]["data"].clear()
                        self.data[i]["iter"] = 0
                case 1:
                    # Clear structure and close pointer for all sources
                    for i,_ in enumerate(self.data):
                        self.data[i]["struct"].clear()
                        self.data[i]["ptr"].close()
                    

def publish(client, topic, datasource, delay):
    # Start reading from the data source
    datasource.startReading()
    while True:
        # Wait for the specified delay
        time.sleep(delay)
        # Read data from the source
        data = datasource.read()
        # Publish the message to the specified topic using the client
        result = client.publish(topic, data.model_dump_json())
        # Check the status of the publish operation
        status = result[0]
        # Check if the publish operation was successful
        if status == 0:
            pass
        else:
            # Print a message if the publish operation failed
            print(f"Failed to send message to topic {topic}")
    # Stop reading from the data source
    datasource.stopReading()


def startPublish(src:DataSource, client, topic):
    # Create a thread for the publish function
    rdr = Thread(target = publish, args = (client, topic, src, 0.1), daemon = True)
    # Start the thread
    rdr.start()
    # Print a message indicating that the reading thread is running
    print("[ALERT]: READING THREAD IS RUNNING AND SENDING DATA")

if __name__ == "__main__":
    # Initialize DataSource object with file names and corresponding structures
    src = DataSource([
        {"name":"./data/accelerometer.csv", "struct":[int, int, int]},
        {"name":"./data/gps.csv", "struct":[float, float]}])
