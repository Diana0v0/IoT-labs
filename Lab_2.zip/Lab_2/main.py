import asyncio
import json

from typing import Set, Dict, List, Any
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Body

from sqlalchemy import (create_engine, MetaData, Table, Column,
                        Integer, String, Float, DateTime)
from sqlalchemy import insert, delete, update
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select
from sqlalchemy.sql.expression import func

from datetime import datetime
from pydantic import BaseModel, field_validator
from config import (POSTGRES_HOST, POSTGRES_PORT, POSTGRES_DB,
                    POSTGRES_USER, POSTGRES_PASSWORD)

# FastAPI app setup
app = FastAPI()
# SQLAlchemy setup
DATABASE_URL = f"postgresql+psycopg2://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
engine = create_engine(DATABASE_URL)
metadata = MetaData()
# Define the ProcessedAgentData table
processed_agent_data = Table(
    "processed_agent_data",
    metadata,
    Column("id", Integer, primary_key = True, index = True),
    Column("road_state", String),
    Column("x", Float),
    Column("y", Float),
    Column("z", Float),
    Column("latitude", Float),
    Column("longitude", Float),
    Column("timestamp", DateTime),
)

# SQLAlchemy model
class ProcessedAgentDataInDB(BaseModel):
    id: int
    road_state: str
    x: float
    y: float
    z: float
    latitude: float
    longitude: float
    timestamp: datetime

class DataRow:
    pass

SessionLocal = sessionmaker(bind = engine)

# FastAPI models
class AccelerometerData(BaseModel):
    x: float
    y: float
    z: float

class GpsData(BaseModel):
    latitude: float
    longitude: float

class AgentData(BaseModel):
    accelerometer: AccelerometerData
    gps: GpsData
    timestamp: datetime

    @classmethod
    @field_validator("timestamp", mode = "before")
    def check_timestamp(cls, value):
        if isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(value)
        except (TypeError, ValueError):
            raise ValueError("Invalid timestamp format. Expected ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ).")

class ProcessedAgentData(BaseModel):
    road_state: str
    agent_data: AgentData


# WebSocket subscriptions
subscriptions: Dict[int, Set[WebSocket]] = {}

# FastAPI WebSocket endpoint
@app.websocket("/ws/")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    subscriptions.add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        subscriptions.remove(websocket)

# Function to send data to subscribed users
async def send_data_to_subscribers(data):
    for websocket in subscriptions:
        await websocket.send_json(json.dumps(data))



# FastAPI CRUDL endpoints
def data_to_db_format(data:ProcessedAgentData, id:int)->ProcessedAgentDataInDB:
    """
    Converts ProcessedAgentData to ProcessedAgentDataInDB structure format that fits database entry structure.
    Parameters:
    - data: ProcessedAgentData object containing the data to convert.
    - id: The ID to assign to the converted data.
    Returns:
    - ProcessedAgentDataInDB object containing the converted data.
    """
    # Create a new ProcessedAgentDataInDB object with the converted data
    result = ProcessedAgentDataInDB(
        id = id,
        road_state = data.road_state,
        x = data.agent_data.accelerometer.x,
        y = data.agent_data.accelerometer.y,
        z = data.agent_data.accelerometer.z,
        latitude = data.agent_data.gps.latitude,
        longitude = data.agent_data.gps.longitude,
        timestamp = data.agent_data.timestamp
        )
    return result


@app.post("/processed_agent_data/")
async def create_processed_agent_data(data: List[ProcessedAgentData]):
    """
    Endpoint to process and store agent data, then send it to subscribers.
    Parameters:
    - data: List of ProcessedAgentData objects containing agent data to be processed and stored.
    Returns:
    - List of ProcessedAgentData objects that were processed.
    """
    # Create a new session
    current_session = SessionLocal()
    # Iterate through each data item
    for row in data:
        # Get the maximum ID from the database
        max_index_query = current_session.query(func.max(processed_agent_data.c.id))
        max_index = current_session.execute(max_index_query).scalar() or 0
        max_index += 1
        # Convert data to database format and insert into the database
        db_entry = data_to_db_format(ProcessedAgentData(**row.model_dump()), max_index)
        db_entry_query = insert(processed_agent_data).values(**db_entry.model_dump())
        current_session.execute(db_entry_query)
        current_session.commit()
        # Send data to subscribers
        await send_data_to_subscribers(db_entry)
    # Return the processed data
    return data


@app.get(
    "/processed_agent_data/{processed_agent_data_id}",
    response_model=ProcessedAgentDataInDB,
)
def read_processed_agent_data(processed_agent_data_id: int):
    """
    Endpoint to read processed agent data by ID.
    Parameters:
    - processed_agent_data_id: The ID of the processed agent data to retrieve.
    Returns:
    - ProcessedAgentDataInDB object containing the retrieved data.
    """
    # Create a new session
    current_session = SessionLocal()
    # Query the database for the specified ID
    db_entry = select(processed_agent_data).filter(processed_agent_data.c.id == processed_agent_data_id).scalar()
    # Check if the entry exists
    if db_entry is None:
        raise HTTPException(status_code = 404, detail = "Entry not found")
    try:
        # Execute the query and get the result
        db_entry = current_session.execute(db_entry).scalar()
    except Exception:
        raise HTTPException(status_code = 404, detail = "Entry not found")
    # Get the field names and create kwargs for model validation
    field_names = ProcessedAgentDataInDB.model_fields.keys()
    kwargs = dict(zip(field_names, db_entry))
    # Validate and return the retrieved data
    return ProcessedAgentDataInDB.model_validate(kwargs)


@app.get("/processed_agent_data/", response_model = list[ProcessedAgentDataInDB])
def list_processed_agent_data():
    """
    Endpoint to list all processed agent data entries.
    Returns:
    - List of ProcessedAgentDataInDB objects containing all processed agent data.
    """
    # Create a new session
    current_session = SessionLocal()
    # Query the database to get all entries
    data_list = current_session.query(processed_agent_data).all()
    # Return the list of data
    return data_list


@app.put(
    "/processed_agent_data/{processed_agent_data_id}",
    response_model=ProcessedAgentDataInDB,
)
def update_processed_agent_data(processed_agent_data_id: int, data: ProcessedAgentData):
    """
    Endpoint to update processed agent data by ID.
    Parameters:
    - processed_agent_data_id: The ID of the processed agent data to update.
    - data: ProcessedAgentData object containing the updated data.
    Returns:
    - ProcessedAgentDataInDB object containing the updated data.
    """
    # Create a new session
    current_session = SessionLocal()
    # Convert data to database format
    db_data = data_to_db_format(data, processed_agent_data_id)
    # Build the update query
    db_query = (
        update(processed_agent_data)
        .where(processed_agent_data.c.id == processed_agent_data_id)
        .values(**db_data.model_dump())
        .returning(processed_agent_data.c)
    )
    try:
        # Execute the update query and get the updated entry
        db_entry = current_session.execute(db_query).scalar_one()
        current_session.commit()
    except Exception:
        # Handle errors and raise an HTTPException
        raise HTTPException(status_code = 404, detail = "Entry not found")
    # Return the updated entry
    return db_entry


@app.delete(
    "/processed_agent_data/{processed_agent_data_id}",
    response_model=ProcessedAgentDataInDB,
)
def delete_processed_agent_data(processed_agent_data_id: int):
    """
    Endpoint to delete processed agent data by ID.
    Parameters:
    - processed_agent_data_id: The ID of the processed agent data to delete.
    Returns:
    - ProcessedAgentDataInDB object containing the deleted data.
    """
    # Create a new session
    current_session = SessionLocal()
    # Build the delete query
    db_query = (
        delete(processed_agent_data)
        .where(processed_agent_data.c.id == processed_agent_data_id)
        .returning(processed_agent_data.c)
    )
    try:
        # Execute the delete query and get the deleted entry
        db_entry = current_session.execute(db_query).scalar_one()
        current_session.commit()
    except Exception:
        # Handle errors and raise an HTTPException
        raise HTTPException(status_code = 404, detail = "Entry not found")
    # Return the deleted entry
    return db_entry


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
